package le.bao.khang;

import le.bao.khang.model.SystemAccount;
import le.bao.khang.repository.SystemAccountRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class KhangApplication {

    public static void main(String[] args) {
        SpringApplication.run(KhangApplication.class, args);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    CommandLineRunner run(SystemAccountRepository systemAccountRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            // 1. Làm sạch Database
            systemAccountRepository.deleteAll();
            System.out.println(">>> Đã xóa dữ liệu cũ trong SystemAccount");

            // 2. Tạo tài khoản mẫu
            SystemAccount admin = new SystemAccount();

            // Các trường kiểu String
            admin.setEmail("manager@system.com");
            admin.setUsername("manager_khang");
            admin.setPassword(passwordEncoder.encode("123456"));

            // SỬA LỖI TẠI ĐÂY: Gán Role là số nguyên (Integer) thay vì "ADMIN"
            // Nếu DB quy định 1 là Admin, hãy để là 1. Nếu không rõ, hãy thử số 1 trước.
            admin.setRole(1);

            // Lưu vào database
            systemAccountRepository.save(admin);

            System.out.println(">>> ĐÃ TẠO USER THÀNH CÔNG VỚI ROLE LÀ INTEGER (1)");
            System.out.println(">>> HÃY THỬ LOGIN TRÊN SWAGGER NGAY");
        };
    }
}