package le.bao.khang.repository;

import le.bao.khang.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {

    // Hàm tìm kiếm tùy chỉnh (Custom JPQL Query)
    // Logic:
    // - Nếu 'name' truyền vào là NULL -> bỏ qua điều kiện tên.
    // - Nếu 'catName' truyền vào là NULL -> bỏ qua điều kiện danh mục.
    // - Dùng LIKE %...% để tìm gần đúng (chứa từ khóa).
    @Query("SELECT p FROM Product p WHERE " +
            "(:name IS NULL OR p.productName LIKE %:name%) AND " +
            "(:catName IS NULL OR p.category.categoryName LIKE %:catName%)")
    List<Product> searchProducts(@Param("name") String name, @Param("catName") String catName);
}