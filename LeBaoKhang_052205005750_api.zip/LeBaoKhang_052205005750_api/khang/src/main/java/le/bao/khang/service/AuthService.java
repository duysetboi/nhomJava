package le.bao.khang.service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import le.bao.khang.dto.LoginResponse;
import le.bao.khang.model.SystemAccount;
import le.bao.khang.repository.SystemAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder; // THÊM DÒNG NÀY
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private SystemAccountRepository accountRepository;

    @Autowired
    private PasswordEncoder passwordEncoder; // THÊM DÒNG NÀY ĐỂ GIẢI MÃ

    private static final String SECRET_STRING = "kjsdhkjshdkjhskjdhfkjshdfkjhsdkjfhskjdfhksjdhfkjsdhf";
    private static final Key SECRET_KEY = Keys.hmacShaKeyFor(SECRET_STRING.getBytes(StandardCharsets.UTF_8));

    public LoginResponse login(String email, String password) {
        Optional<SystemAccount> userOpt = accountRepository.findByEmail(email);

        if (userOpt.isPresent()) {
            SystemAccount user = userOpt.get();

            // --- SỬA TẠI ĐÂY: Dùng matches thay vì equals ---
            // passwordEncoder.matches(mật_khẩu_thô, mật_khẩu_đã_mã_hóa_trong_db)
            if (passwordEncoder.matches(password, user.getPassword())) {

                String roleName = getRoleName(user.getRole());
                if(roleName.equals("Others")) return null;

                String token = generateToken(user.getEmail(), roleName);
                return new LoginResponse(token, roleName);
            }
        }
        return null;
    }

    private String getRoleName(Integer roleId) {
        if (roleId == null) return "Others";
        switch (roleId) {
            case 1: return "admin";
            case 2: return "manager";
            case 3: return "analyst";
            default: return "Others";
        }
    }

    private String generateToken(String email, String role) {
        long expirationTime = 86400000;
        return Jwts.builder()
                .setSubject(email)
                .claim("role", role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationTime))
                .signWith(SECRET_KEY, SignatureAlgorithm.HS256)
                .compact();
    }
}