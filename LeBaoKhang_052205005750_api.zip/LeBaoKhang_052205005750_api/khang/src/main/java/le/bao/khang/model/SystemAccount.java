package le.bao.khang.model;

import jakarta.persistence.*;

@Entity
@Table(name = "SystemAccounts")
public class SystemAccount {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer accountID;

    private String username;

    @Column(unique = true)
    private String email;

    private String password;

    private Integer role; // 1: admin, 2: manager, 3: analyst

    private Boolean isActive;

    // --- THÊM THỦ CÔNG GETTER & SETTER (Thay cho @Data) ---

    public Integer getAccountID() {
        return accountID;
    }

    public void setAccountID(Integer accountID) {
        this.accountID = accountID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
}