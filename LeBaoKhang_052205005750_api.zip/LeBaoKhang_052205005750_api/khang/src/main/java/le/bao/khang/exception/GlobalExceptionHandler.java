package le.bao.khang.exception;

import le.bao.khang.dto.ErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.util.NoSuchElementException;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // 1. Lỗi Validation (PR40001) - 400 Bad Request
    // Xảy ra khi gửi thiếu field bắt buộc hoặc sai định dạng
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException ex) {
        String msg = ex.getBindingResult().getFieldError().getDefaultMessage();
        return new ResponseEntity<>(new ErrorResponse("PR40001", msg), HttpStatus.BAD_REQUEST);
    }

    // Xử lý thêm ngoại lệ chung cho Bad Request
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorResponse> handleIllegalArgument(IllegalArgumentException ex) {
        return new ResponseEntity<>(new ErrorResponse("PR40001", ex.getMessage()), HttpStatus.BAD_REQUEST);
    }

    // 2. Lỗi Xác thực (PR40101) - 401 Unauthorized
    // Xảy ra khi login sai pass hoặc token đểu
    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<ErrorResponse> handleAuthError(BadCredentialsException ex) {
        return new ResponseEntity<>(new ErrorResponse("PR40101", "Authentication failed"), HttpStatus.UNAUTHORIZED);
    }

    // 3. Lỗi Quyền truy cập (PR40301) - 403 Forbidden
    // Xảy ra khi User thường cố vào trang Admin
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ErrorResponse> handleAccessDenied(AccessDeniedException ex) {
        return new ResponseEntity<>(new ErrorResponse("PR40301", "Not authorized to access this resource"), HttpStatus.FORBIDDEN);
    }

    // 4. Lỗi Không tìm thấy (PR40401) - 404 Not Found
    // Xảy ra khi tìm ID sản phẩm không tồn tại
    @ExceptionHandler({NoSuchElementException.class, NoResourceFoundException.class})
    public ResponseEntity<ErrorResponse> handleNotFound(Exception ex) {
        return new ResponseEntity<>(new ErrorResponse("PR40401", "Resource not found"), HttpStatus.NOT_FOUND);
    }

    // 5. Lỗi Server (PR50001) - 500 Internal Server Error
    // Các lỗi không xác định còn lại
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGlobalError(Exception ex) {
        // In lỗi ra console để debug
        ex.printStackTrace();
        return new ResponseEntity<>(new ErrorResponse("PR50001", "Internal Server Error"), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}