package le.bao.khang.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;

// Import này cần thiết để dùng withDefaults()
import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // 1. Tắt CSRF: Để test API qua Postman/Swagger dễ dàng hơn
                .csrf(AbstractHttpConfigurer::disable)

                // 2. Cấu hình quyền truy cập (Authorize)
                .authorizeHttpRequests(auth -> auth
                        // --- MỞ KHÓA CHO SWAGGER (BẮT BUỘC) ---
                        .requestMatchers(
                                "/v3/api-docs/**",
                                "/swagger-ui/**",
                                "/swagger-ui.html"
                        ).permitAll()

                        // --- MỞ KHÓA CHO API AUTH (Đăng ký/Đăng nhập) ---
                        // Đảm bảo Controller của bạn dùng @RequestMapping("/api/auth")
                        .requestMatchers("/api/auth/**").permitAll()

                        // --- CÁC REQUEST KHÁC ---
                        // Bắt buộc phải đăng nhập mới được truy cập
                        .anyRequest().authenticated()
                )

                // 3. Sử dụng Basic Auth (Hiện popup đăng nhập mặc định của trình duyệt)
                // Đây là cách đơn giản nhất để test khi chưa tích hợp JWT hoàn chỉnh
                .httpBasic(withDefaults());

        /* * LƯU Ý: Do trong hình mình thấy bạn có file JwtAuthenticationFilter,
         * nếu sau này bạn muốn bật tính năng đăng nhập bằng Token (JWT),
         * bạn sẽ cần thêm dòng này vào trước .build():
         * * .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
         * * Hiện tại cứ để Basic Auth chạy trước cho Swagger lên hình đã nhé!
         */

        return http.build();
    }
}