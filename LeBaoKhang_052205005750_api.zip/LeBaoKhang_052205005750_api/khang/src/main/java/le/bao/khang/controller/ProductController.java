package le.bao.khang.controller;

import jakarta.validation.Valid;
import le.bao.khang.dto.ProductDTO;
import le.bao.khang.model.Category;
import le.bao.khang.model.Product;
import le.bao.khang.repository.CategoryRepository;
import le.bao.khang.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    // 1. GET ALL
    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        return ResponseEntity.ok(productRepository.findAll());
    }

    // 2. GET BY ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getProductById(@PathVariable int id) {
        Optional<Product> p = productRepository.findById(id);
        if (p.isPresent()) return ResponseEntity.ok(p.get());

        // Ném lỗi để GlobalExceptionHandler bắt (PR40401)
        throw new java.util.NoSuchElementException("Product not found with id: " + id);
    }

    // 3. ADD PRODUCT
    // Thêm @Valid để kích hoạt kiểm tra lỗi từ DTO
    @PostMapping
    @PreAuthorize("hasAnyAuthority('admin', 'manager')")
    public ResponseEntity<?> addProduct(@Valid @RequestBody ProductDTO dto) {

        // Kiểm tra Category có tồn tại không
        Category cat = categoryRepository.findById(dto.getCategoryId())
                .orElseThrow(() -> new IllegalArgumentException("Category ID not found")); // PR40001

        Product p = new Product();
        p.setProductName(dto.getProductName());
        p.setPrice(dto.getPrice());
        p.setQuantity(dto.getQuantity());
        p.setCategory(cat);
        // Lưu ý: ReleasedDate set mặc định hoặc xử lý nếu cần

        productRepository.save(p);
        return ResponseEntity.status(HttpStatus.CREATED).body(p);
    }

    // 4. UPDATE PRODUCT
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('admin', 'manager')")
    public ResponseEntity<?> updateProduct(@PathVariable int id, @Valid @RequestBody ProductDTO dto) {
        Product p = productRepository.findById(id)
                .orElseThrow(() -> new java.util.NoSuchElementException("Product not found")); // PR40401

        // Cập nhật thông tin
        p.setProductName(dto.getProductName());
        p.setPrice(dto.getPrice());
        p.setQuantity(dto.getQuantity());

        // Cập nhật danh mục nếu có thay đổi
        if (dto.getCategoryId() != null) {
            Category cat = categoryRepository.findById(dto.getCategoryId())
                    .orElseThrow(() -> new IllegalArgumentException("Category ID not found"));
            p.setCategory(cat);
        }

        productRepository.save(p);
        return ResponseEntity.ok(p);
    }

    // 5. DELETE PRODUCT
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('admin')") // Chỉ Admin được xóa
    public ResponseEntity<?> deleteProduct(@PathVariable int id) {
        if (!productRepository.existsById(id)) {
            throw new java.util.NoSuchElementException("Product not found"); // PR40401
        }
        productRepository.deleteById(id);
        return ResponseEntity.ok("Deleted successfully");
    }

    // 6. SEARCH
    @GetMapping("/search")
    public ResponseEntity<List<Product>> search(@RequestParam(required = false) String name,
                                                @RequestParam(required = false) String category) {
        return ResponseEntity.ok(productRepository.searchProducts(name, category));
    }
}