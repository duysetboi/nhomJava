package le.bao.khang.repository;

import le.bao.khang.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    // Hàm này rất quan trọng để chức năng login tìm người dùng
    Optional<User> findByEmail(String email);
}