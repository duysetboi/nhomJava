package le.bao.khang.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public class ProductDTO {

    @Pattern(regexp = "^[A-Z][a-zA-Z0-9\\s]{2,50}$", message = "Product name must start with Capital, alphanumeric, length 3-51")
    @NotBlank(message = "Product name is required")
    private String productName;

    @Positive(message = "Price must be > 0")
    private BigDecimal price;

    @Min(value = 0, message = "Quantity must be >= 0")
    private Integer quantity;

    @NotNull(message = "Category ID is required")
    private Integer categoryId;

    // --- THÊM THỦ CÔNG GETTER & SETTER ---

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }
}