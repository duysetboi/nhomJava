package le.bao.khang.dto;

public class ErrorResponse {
    private String errorCode;
    private String message;

    // 1. Constructor mặc định (bắt buộc)
    public ErrorResponse() {
    }

    // 2. Constructor có tham số (SỬA LỖI CỦA BẠN Ở ĐÂY)
    public ErrorResponse(String errorCode, String message) {
        this.errorCode = errorCode;
        this.message = message;
    }

    // 3. Getter và Setter thủ công
    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}