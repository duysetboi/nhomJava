package le.bao.khang.repository;

import le.bao.khang.model.SystemAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface SystemAccountRepository extends JpaRepository<SystemAccount, Integer> {
    // Sửa/Thêm dòng này
    Optional<SystemAccount> findByEmail(String email);
}