package le.bao.khang.dto;

public class LoginResponse {
    private String token;
    private String role;

    // 1. Constructor rỗng (Mặc định)
    public LoginResponse() {
    }

    // 2. Constructor có tham số (SỬA LỖI CỦA BẠN Ở ĐÂY)
    public LoginResponse(String token, String role) {
        this.token = token;
        this.role = role;
    }

    // 3. Getter và Setter thủ công
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}