package le.bao.khang.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore; // 1. Nhớ import dòng này
import java.util.List;

@Entity
public class Category {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer categoryID;

    private String categoryName;
    private String description;

    @OneToMany(mappedBy = "category")
    @JsonIgnore // 2. Thêm dòng này để ngắt vòng lặp vô tận
    private List<Product> products;

    // --- GETTER & SETTER THỦ CÔNG ---

    public Integer getCategoryID() {
        return categoryID;
    }

    public void setCategoryID(Integer categoryID) {
        this.categoryID = categoryID;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }
}