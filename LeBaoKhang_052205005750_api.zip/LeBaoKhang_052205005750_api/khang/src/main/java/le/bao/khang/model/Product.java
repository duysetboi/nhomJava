package le.bao.khang.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties; // 1. Import thư viện này
import java.math.BigDecimal;
import java.util.Date;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer productID;

    private String productName;
    private String material;
    private BigDecimal price;
    private Integer quantity;

    @Temporal(TemporalType.DATE)
    private Date releasedDate;

    @ManyToOne(fetch = FetchType.LAZY) // Nên để LAZY để tối ưu hiệu suất
    @JoinColumn(name = "CategoryID")
    // 2. Dòng này giúp sửa lỗi 500 khi Swagger cố đọc dữ liệu Category
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private Category category;

    // --- GETTER & SETTER ---

    public Integer getProductID() {
        return productID;
    }

    public void setProductID(Integer productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Date getReleasedDate() {
        return releasedDate;
    }

    public void setReleasedDate(Date releasedDate) {
        this.releasedDate = releasedDate;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
}