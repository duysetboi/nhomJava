package le.bao.khang.config;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    // Key này PHẢI GIỐNG Y HỆT bên AuthService (thực tế nên để trong file properties)
    private static final String SECRET = "kjsdhkjshdkjhskjdhfkjshdfkjhsdkjfhskjdfhksjdhfkjsdhf";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        // 1. Lấy token từ header "Authorization"
        String authHeader = request.getHeader("Authorization");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7); // Cắt bỏ chữ "Bearer "
            try {
                // 2. Giải mã Token
                Claims claims = Jwts.parserBuilder()
                        .setSigningKey(Keys.hmacShaKeyFor(SECRET.getBytes(StandardCharsets.UTF_8))) // Tự fix key cho khớp logic cũ nếu cần
                        // Lưu ý: Nếu bên AuthService bạn dùng Key object thì ở đây cũng phải dùng logic tương tự.
                        // Để đơn giản và chắc chắn chạy được với code cũ, tôi dùng cách parse cơ bản nhất:
                        .build()
                        .parseClaimsJws(token)
                        .getBody();

                String email = claims.getSubject();
                String role = claims.get("role", String.class);

                if (email != null) {
                    // 3. Tạo thông tin User để Spring Security hiểu
                    SimpleGrantedAuthority authority = new SimpleGrantedAuthority(role); // Ví dụ: "admin"
                    UsernamePasswordAuthenticationToken authentication =
                            new UsernamePasswordAuthenticationToken(email, null, Collections.singletonList(authority));

                    // 4. Lưu vào Context (Đăng nhập thành công cho request này)
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                }
            } catch (Exception e) {
                // Token lỗi hoặc hết hạn -> Không làm gì cả, để Security tự chặn
                System.out.println("Token Error: " + e.getMessage());
            }
        }
        filterChain.doFilter(request, response);
    }
}