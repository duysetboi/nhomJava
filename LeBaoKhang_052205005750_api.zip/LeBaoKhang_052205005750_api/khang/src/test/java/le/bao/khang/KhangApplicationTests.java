package le.bao.khang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KhangApplicationTests {

	@Test
	void contextLoads() {
	}

}
